import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import './App.css';
import LandingPage from './pages/LandingPage';
import PiratenStory from './pages/PiratenStory';
import HistorikStory from './pages/HistorikStory';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import ProfilePage from './pages/ProfilePage';
import 'leaflet/dist/leaflet.css';


// Styles für Seiten
import './styles/LoginPage.css';

// MUI Imports
import { ThemeProvider } from '@mui/material/styles';
import retroTheme from './theme';  // Importiere dein Retro-Theme

function App() {
  return (
    // ThemeProvider um die gesamte App legen, damit das Theme überall verfügbar ist
    <ThemeProvider theme={retroTheme}>
      <Router>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/piraten" element={<PiratenStory />} />
          <Route path="/historik" element={<HistorikStory />} />
          <Route path="/profil" element={<ProfilePage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
        </Routes>
      </Router>
    </ThemeProvider>
  );
}

export default App;
