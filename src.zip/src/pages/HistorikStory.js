import React from 'react';

const HistorikStory = () => {
    return (
        <div>
            <h1>Die Historik Geschichte</h1>
            <p>Hier beginnt deine historische Reise!</p>
        </div>
    );
};

export default HistorikStory;
