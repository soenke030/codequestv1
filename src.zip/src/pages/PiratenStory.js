import React, { useState, useEffect } from 'react';
import { supabase } from '../supabaseClient';
import { Box, Typography, CircularProgress } from '@mui/material';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

const PiratenStory = () => {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true); // Ladezustand
  const [error, setError] = useState(null); // Fehlerzustand
  const [map, setMap] = useState(null); // Zustand für die Karte
  const [qrCodeResult, setQrCodeResult] = useState(null); // QR-Code-Resultat

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const { data: { user }, error } = await supabase.auth.getUser();
        if (error) throw error;

        if (user) {
          const { data: profile, error: profileError } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', user.id)
            .single();

          if (profileError) throw profileError;

          setProfile(profile);
        } else {
          setError('Benutzer nicht authentifiziert.');
        }
      } catch (err) {
        setError(err.message || 'Fehler beim Laden des Profils.');
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();
  }, []);

  useEffect(() => {
    // Initialisiere die Leaflet-Karte nur, wenn sie noch nicht existiert
    if (profile && profile.progress === 0 && !map) {
      const initializedMap = L.map('map').setView([53.691712548796104, 7.802534736928744], 15);

      // OpenStreetMap-Tiles hinzufügen
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      }).addTo(initializedMap);

      // Marker hinzufügen
      L.marker([53.691712548796104, 7.802534736928744]).addTo(initializedMap)
        .bindPopup('Startpunkt der Piratengeschichte')
        .openPopup();

      setMap(initializedMap); // Karte speichern
    }
  }, [profile, map]);

  // Lade- und Fehlerzustände behandeln
  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" height="100vh">
        <CircularProgress />
        <Typography>Lade dein Profil...</Typography>
      </Box>
    );
  }

  if (error) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" height="100vh">
        <Typography color="error">Fehler: {error}</Typography>
      </Box>
    );
  }

  return (
    <Box
      display="flex"
      flexDirection="column"
      justifyContent="center"
      alignItems="center"
      minHeight="100vh"
      px={3}
    >
      <Typography variant="h4" gutterBottom sx={{ fontFamily: 'Courier New, monospace', color: 'primary.main' }}>
        Die Piraten Geschichte
      </Typography>

      {profile ? (
        <Box>
          <Typography variant="h6">Willkommen, {profile.email}. Dein Fortschritt: {profile.progress}/5 Anlaufpunkte</Typography>
          
          {profile.progress === 0 && (
            <Box mt={3} width="100%">
              <Typography variant="h6">Gehe zum Startpunkt, um die Geschichte zu beginnen!</Typography>
              <Box id="map" mt={2} sx={{ width: '100%', height: '400px', borderRadius: '10px', boxShadow: 3 }}></Box>
              <Typography mt={2}>
                Standort: <strong>53.691712548796104, 7.802534736928744</strong>
              </Typography>
              <Typography>Scanne den QR-Code, um den ersten Punkt zu aktivieren!</Typography>
            </Box>
          )}

          {profile.progress > 0 && (
            <Typography mt={3}>Du hast bereits begonnen! Gehe zum nächsten Punkt, um fortzufahren.</Typography>
          )}
        </Box>
      ) : (
        <Typography>Profil konnte nicht geladen werden.</Typography>
      )}
    </Box>
  );
};

export default PiratenStory;
